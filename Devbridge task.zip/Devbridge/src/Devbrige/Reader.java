package Devbrige;

import java.util.Scanner;

public class Reader {
	static String[] arr = new String[1];

	static Scanner text = new Scanner(System.in); 
	static String txt = text.nextLine(); 


static void myMethon(String... args) {

	
	int i = 0;
	  for (String arg : args) {
		  for (char c : arg.toCharArray()) {
			  if (i == 1 && Character.isDigit(c)) {
				  System.out.println(arg);
				  break;
			  }
			  if (Character.isDigit(c) && Character.getNumericValue(c) >= 1) {
				  i = 1;
			  }
			  else {
					  i = 0;
			  }
		  }
		
	  }
}
  
	    
public static void main(String[] args) {
	// TODO Auto-generated method stub

		myMethon(txt);

	}
}

